const recipes = [
    {
        name: "Potion of Vitality",
        ingredients: ["unicorn-hair", "gillyweed", "phoenix-tears", "dittany-leaves", "leeches"]
    },
    {
        name: "Elixir of Strength",
        ingredients: ["dragon-scales", "bat-wings", "bezoar", "mandrake-root", "dittany-leaves"]
    },
    {
        name: "Memory Potion",
        ingredients: ["mandrake-root", "dittany-leaves", "leeches", "phoenix-tears", "bezoar"]
    },
    {
        name: "Invisibility Draught",
        ingredients: ["gillyweed", "boomslang-skin", "unicorn-hair", "dittany-leaves", "phoenix-tears"]
    },
    {
        name: "Sleeping Potion",
        ingredients: ["leeches", "bat-wings", "mandrake-root", "dittany-leaves", "phoenix-tears"]
    }
];


